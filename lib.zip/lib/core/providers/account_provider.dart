import 'package:flutter/cupertino.dart';

class AccountProvider {
  
}

class AuthProvider {
  bool get loggedIn => null;

  get user => null;
}