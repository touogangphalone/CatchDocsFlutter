

class GeolocatorService {
  
}
