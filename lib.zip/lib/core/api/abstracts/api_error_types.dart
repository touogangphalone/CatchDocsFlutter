class ApiErrorType{
  static String parseError  = "PARSE_ERROR";
  static String validationError = "VALIDATION_ERROR";
  static String authorisationError= "AUTHORIZATION_ERROR";
  static String networkError= "NETWORK_ERROR";
  static String genericError= "GENERIC_ERROR";
}