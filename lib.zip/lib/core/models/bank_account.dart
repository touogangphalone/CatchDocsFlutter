abstract class BankAccount {
  String getBranch();
  String getDev();

  String getAccountNumber();
  String getAccountName();
  num getIndicativeBalance();
  num getAvailableBalance();
}
