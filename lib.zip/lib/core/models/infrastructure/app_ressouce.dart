import '../../persistence/abstract/abstract_persister.dart';

class ApplicationRessource {
  final AbstractPersister persister;

  ApplicationRessource({this.persister});
}
